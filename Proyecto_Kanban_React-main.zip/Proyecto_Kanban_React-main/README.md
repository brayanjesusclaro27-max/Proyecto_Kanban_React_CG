# Proyecto_Kanban_React
El proyecto resuelve la dificultad de organizar y dar seguimiento a tareas cuando la información está dispersa en mensajes, notas o listas. El tablero Kanban concentra las actividades y permite conocer su estado y prioridad.
